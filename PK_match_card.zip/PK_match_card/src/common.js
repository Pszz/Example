// 牌数组数据
var card_str = [
    [0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E], // --方块 2 - A
    [0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E], // --梅花 2 - A
    [0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E], // --红桃 2 - A
    [0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E], // --黑桃 2 - A
    [0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E], // --加色一
    [0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E], // --加色二
    [0x4F, 0x5F]
];

// 渲染牌池dom
for (var i = 0; i < 4; i++) {
    for (var j in card_str[i]) {
        var pkp = '<img src="img/' + card_str[i][j] + '.png" />';
        var html = '<li class="card_style" data-val="' + card_str[i][j] + '">' + pkp + '</li>';
        $(".card_pond ul").eq(i).append(html);
    }
}

var king_dom = '';
for (var j in card_str[6]) {
    var pkp = '<img src="img/' + card_str[6][j] + '.png" />';
    king_dom += '<li class="card_style" data-val="' + card_str[6][j] + '">' + pkp + '</li>';
}

var jia_noe_dom = '';
for (var j in card_str[4]) {
    var pkp = '<img src="img/' + card_str[4][j] + '.png" />';
    jia_noe_dom += '<li class="card_style" data-val="' + card_str[4][j] + '">' + pkp + '</li>';
}

var jia_two_dom = '';
for (var j in card_str[5]) {
    var pkp = '<img src="img/' + card_str[5][j] + '.png" />';
    jia_two_dom += '<li class="card_style" data-val="' + card_str[5][j] + '">' + pkp + '</li>';
}

// 选择条件
var isKing = $("input[name='isKing']:checked").val();
var isColor = $("input[name='isColor']:checked").val();
var isNumber = $("input[name='isNumber']:checked").val();
var isJustment = $("input[name='isJustment']:checked").val();

// 条件选择
$("input[name='isKing']").change(function() {
    isKing = this.value;
    if (isKing == 0) {
        $(".card_pond ul").eq(6).hide().html('');
    } else {
        $(".card_pond ul").eq(6).show().html(king_dom);
        $(".card_pond ul").eq(6).css('margin-top', '-270px');           
    }
    pickCard();
});

$("input[name='isColor']").change(function() {
    isColor = this.value;
    if (isColor == 2) {
        $(".card_pond ul").eq(4).show().html(jia_noe_dom);
        $(".card_pond ul").eq(5).show().html(jia_two_dom);
        $(".card_pond ul").eq(6).css('margin-top', '0');
    } else if (isColor == 1) {
        $(".card_pond ul").eq(4).show().html(jia_noe_dom);
        $(".card_pond ul").eq(5).hide().html('');
        $(".card_pond ul").eq(6).css('margin-top', '0');
    } else {
        $(".card_pond ul").eq(4).hide().html('');
        $(".card_pond ul").eq(5).hide().html('');
        $(".card_pond ul").eq(6).css('margin-top', '-270px');
    }
    pickCard();
});

$("input[name='isNumber']").change(function() {
    isNumber = this.value;
    if (isNumber == 1) {
        $('.set_card .item').hide();
        $('.set_card .item').eq(0).show();
    } else if (isNumber == 2) {
        $('.set_card .item').hide();
        $('.set_card .item').eq(0).show();
        $('.set_card .item').eq(1).show();
    } else if (isNumber == 3) {
        $('.set_card .item').show();
        $('.set_card .item').eq(3).hide();
        $('.set_card .item').eq(4).hide();
        $('.set_card .item').eq(5).hide();
    } else if (isNumber == 4) {
        $('.set_card .item').show();
        $('.set_card .item').eq(4).hide();
        $('.set_card .item').eq(5).hide();
    } else if (isNumber == 5) {
        $('.set_card .item').show();
        $('.set_card .item').eq(5).hide();
    } else {
        $('.set_card .item').show();
    }
});

$("input[name='isJustment']").change(function() {
    isJustment = this.value;
});

// 手动选牌
function pickCard(){
    $('.card_pond ul').each(function(i) {
        $(this).find('li').each(function(j) {
            $(this).off('click').on('click',function() {
                var lenLi = $('.card_list').eq(isJustment - 1).find('li').length + 1;
                if (lenLi <= 13) {
                    var html = '<li class="card_style" data-val="' + $(this).attr('data-val') + '">' + $(this).html() + '</li>';
                    $(".card_list").eq(isJustment - 1).append(html);
                    $(this).hide();
                    revoke();
                };
            });
        });
    });    
}

// 手动撤销选牌
function revoke(argument) {
    $(".card_list").each(function(i) {
        $(this).find('li').each(function() {
            $(this).off('click').on('click',function() {
                if ((i + 1) != isJustment)  return;
                var _this = $(this);
                $(".card_pond .card_style[data-val=" + _this.attr('data-val') + "]").eq(0).show();
                _this.remove();
            });
        });
    });
}

pickCard();

// 随机发牌
var newArr = []; // 新的牌数组，用于发牌
$(".start").click(function() {
    newArr.splice(0,newArr.length)
    for(var i = 0; i < card_str.length; i++){
        if(isKing == 0 && i == 6) continue 
        if(isColor == 0 && (i == 4 || i == 5)) continue
        if(isColor == 1 && i == 5) continue
        for(var j = 0; j < card_str[i].length; j++){
            newArr.push(card_str[i][j]);
        }                                          
    }
    newArr.sort(function(){ return 0.5 - Math.random() });
    licensing();
});

// 开始发牌
function licensing(){
    var i = 0; // 正在发牌家数
    var j = 0; // 已发牌数
    var total = isNumber * 13; // 需要发牌总数
    var timer = setInterval(function(){
        i++;
        if(i == isNumber){i = 0;}
        var pkp = '<img src="img/' + newArr[0] + '.png" />';
        var html = '<li class="card_style" data-val="' + newArr[0] + '">' + pkp + '</li>';
        $(".card_list").eq(i).append(html);
        $(".card_pond .card_style[data-val=" + newArr[0] + "]").hide();
        newArr.splice(0,1);
        j++;
        if(j == total){clearInterval(timer);revoke();}
    },10);
}

// 生成数据
$("#return_json_btn").click(function(){
    var jsonArr = new Array(isNumber - 1)
    $(".item").each(function(i){
        if(i < isNumber){
            $(this).find('li').each(function(j) {
                var jsonItem = Number($(this).attr('data-val')).toString(16);
                if(j == 0){
                    jsonArr[i] = '0x' + p(jsonItem) + ',';
                }else if(j == 12){
                    jsonArr[i] += '0x' + p(jsonItem);
                }else{
                    jsonArr[i] += '0x' + p(jsonItem) + ',';
                }            
            });         
        }
    });
    var htmldata = '';
    for(var i = 0; i < jsonArr.length; i++){
        htmldata += '{' + jsonArr[i] + '},' + '\n';     
    }
    $('#return_json').val(htmldata)
});

function p(s) {
    return s.length == 1 ? '0' + s : s;
}

// 生成
$("#return_pai_btn").click(function(){
    var arr = [];
    var json = $('#return_json').val().split('},');
    for(var i = 0; i < json.length - 1; i++){
        arr.push(json[i].split('{')[1]);
    }
    for(var i = 0; i < arr.length; i++){
        var n_arr = arr[i].split(',');
        for(var j = 0; j < n_arr.length; j++){
            var pkp = '<img src="img/' + parseInt(n_arr[j]) + '.png" />';
            var html = '<li class="card_style" data-val="' + parseInt(n_arr[j]) + '">' + pkp + '</li>';
            $(".card_list").eq(i).append(html);
            $(".card_pond .card_style[data-val=" + parseInt(n_arr[j]) + "]").hide();              
        }
    }
    revoke();
});